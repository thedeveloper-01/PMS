"""
Payroll Management System
A desktop application built with PySide6 and MongoDB
"""

__version__ = "1.0.0"

