"""
Module entry point.

Run with:
    python -m payroll_system
"""

from payroll_system.main import main

if __name__ == "__main__":
    main()


