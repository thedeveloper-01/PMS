"""
GUI components using PySide6
"""

