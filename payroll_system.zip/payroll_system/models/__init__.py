"""
Data models for the Payroll Management System
"""

