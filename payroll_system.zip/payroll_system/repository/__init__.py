"""
Repository layer for database operations
"""

