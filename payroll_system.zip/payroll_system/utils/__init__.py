"""
Utility functions and helpers
"""

